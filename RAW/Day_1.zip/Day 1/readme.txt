Today we will see an introduction to the Python Programming language, with the slides of the Hermess'talk, and in the second half of the class we will do some exercises.

Script of the session

-First 2 hours: Introduction to Python (Hermes slides)
-3rd hour: Install python/conda/jupyter notebooks and explain basic functionality
-4th hour: Python exercises

