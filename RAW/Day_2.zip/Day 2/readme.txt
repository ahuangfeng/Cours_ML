En este dia aprenderemos a utilizar la potente libreria numpy.

Primero, instalación.

Notebooks:

1.- Numpy Arrays (introducción y funcionalidades básicas)
2.- Numpy Indexing and Selection
3.- Numpy Operations
4.- Numpy Exercises
